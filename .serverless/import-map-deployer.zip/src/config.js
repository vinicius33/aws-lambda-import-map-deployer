"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var config_json_1 = __importDefault(require("./config.json"));
exports.config = config_json_1.default;
exports.getConfig = function () { return exports.config; };
//# sourceMappingURL=config.js.map